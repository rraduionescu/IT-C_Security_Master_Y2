import java.*;
import java.lang.*;

class Angajat extends java.lang.Object {
public String Nume;
public int id;

public Angajat(String aNume,int nr){
	Nume = aNume;
	id = nr;
	prelDate(aNume, nr);

}

public String NumeAngajat(){
	return this.Nume;
}

public int IDAngajat(){
	return this.id;
}

public void prelDate(String sNume,int snr){
}

}

