import java.*;

public class ByteStr {

public static void main(String argv[]){
	int x, y, z;
	x = 1;
	y = 2;
	z = x+y;

}
}

