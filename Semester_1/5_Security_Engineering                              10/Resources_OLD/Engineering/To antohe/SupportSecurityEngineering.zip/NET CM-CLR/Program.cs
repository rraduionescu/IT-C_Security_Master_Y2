﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AngajatApplication
{
    class Angajat
    {
        public String Nume;
        public int id;

        public Angajat(String aNume, int nr)
        {
            Nume = aNume;
            id = nr;
            prelDate(aNume, nr);
        }

        public String NumeAngajat()
        {
            return this.Nume;
        }

        public int IDAngajat()
        {
            return this.id;
        }

        public void prelDate(String sNume, int snr) { }

        public static void Main() { }
    }
}
