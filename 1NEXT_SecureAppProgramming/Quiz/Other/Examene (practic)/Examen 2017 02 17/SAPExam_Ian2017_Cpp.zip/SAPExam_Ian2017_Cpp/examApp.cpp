#include <string.h>

void main() {
	// insert declarations, prepare buffers, get file handlers (fopen)

	// AES CBC - decryption key
	unsigned char AES_KEY[16] = {0x2A, 0x4D, 0x61, 0x73, 0x74, 0x65, 0x72, 0x20, 0x49, 0x53, 0x4D, 0x20, 0x32, 0x30, 0x31, 0x37};

	// AES CBC - IV content
	unsigned char iv[16];
	memset(&iv, 0x01, sizeof(iv));

	// call function to decrypt inputEnc.txt (getInfo)

	// print decrypted inputEnc.txt

	// call function to decrypt MsgEnc.txt (RSADecrypt)

	// call function to calculate the message digest for decrypted message (getSHA1)

	// print the message digest

	// compare message digest calculated by getSHA1 with the one stored by decrypted inputEnc.txt (on 2nd line)

	// print the result of the comparision

	// deallocate buffers and close the file handlers

}